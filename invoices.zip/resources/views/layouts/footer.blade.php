<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
            <strong>Made By <span class="fa fa-coffee"></span> & <span class="fa fa-heart"></span> .</strong> All rights
            reserved.
		</div>
	</div>
<!-- Footer closed -->
